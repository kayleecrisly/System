#!/usr/bin/env bash
set -u -o pipefail
batch_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
tool_prefix=/home/kaylee/circt-workspace/workspace/zephyrproject/sdk/gnu/riscv64-zephyr-elf/bin/riscv64-zephyr-elf-
"${tool_prefix}gcc" --version > "$batch_dir/compiler-version.txt" 2>&1
"${tool_prefix}gcc" -print-multi-lib > "$batch_dir/compiler-multilib.txt" 2>&1
"${tool_prefix}gcc" -march=rv32emc -mabi=ilp32e -print-multi-directory > "$batch_dir/official-flags-multilib.txt" 2>&1
make -C "$batch_dir/official-snapshot/sdk/projects/examples/driver/timer" -j1 V=1 \
  "CC=${tool_prefix}gcc" "LD=${tool_prefix}ld" "AR=${tool_prefix}ar" \
  "AS=${tool_prefix}as" "OBJDUMP=${tool_prefix}objdump" "OBJCOPY=${tool_prefix}objcopy" \
  2>&1 | tee "$batch_dir/official-build.log"
build_rc=${PIPESTATUS[0]}
printf '%s\n' "$build_rc" > "$batch_dir/official-build-exit-code.txt"
exit "$build_rc"
