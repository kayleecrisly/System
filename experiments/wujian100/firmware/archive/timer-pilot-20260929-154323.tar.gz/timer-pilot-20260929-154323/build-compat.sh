#!/usr/bin/env bash
set -u -o pipefail
batch_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
tool_prefix=/home/kaylee/circt-workspace/workspace/zephyrproject/sdk/gnu/riscv64-zephyr-elf/bin/riscv64-zephyr-elf-
make -C "$batch_dir/compat-snapshot/sdk/projects/examples/driver/timer" \
  -f "$batch_dir/compat.mk" -j1 V=1 all \
  "CC=${tool_prefix}gcc" "LD=${tool_prefix}ld" "AR=${tool_prefix}ar" \
  "AS=${tool_prefix}as" "OBJDUMP=${tool_prefix}objdump" "OBJCOPY=${tool_prefix}objcopy" \
  2>&1 | tee "$batch_dir/compat-build.log"
build_rc=${PIPESTATUS[0]}
printf '%s\n' "$build_rc" > "$batch_dir/compat-build-exit-code.txt"
exit "$build_rc"
