include Makefile

# The modern toolchain separates CSR operations from the base ISA.
# Retain the official TARGET_CPU branch, ABI, sources, and startup.
CFLAGS += -march=rv32emc_zicsr
LDFLAGS += -march=rv32emc_zicsr -Wl,-Map=out/wujian100_open_evb.map
